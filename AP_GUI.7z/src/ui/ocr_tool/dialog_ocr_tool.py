from PyQt5 import QtGui, QtCore
from PyQt5.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout, QAction, QMenuBar, QApplication,\
     QToolButton, QToolBar, QMessageBox, QFileDialog, QSlider
from PyQt5.QtGui import QPixmap, QImage, QIcon, QPainter, QPen
from PyQt5.QtCore import pyqtSlot, QRect, Qt, QPoint

import pyautogui
import numpy as np
# from time import time
import os
import cv2

from ui.dialog_close import dialogClose
# from util.helper.logger import logger
# from util.helper.logger import logTypes
import util.helper.others as others
# from util.helper.video.videoStream import videoStream
# from util.helper.video.testBildStream import testBildStream
# from ui.helper.dialog_settings import settings
# from util.helper.settingsHandler import settingsHandler
# from util.helper.video.rect import rectangle
# from ui.helper.styles import stylesheets
# from util.helper.video.imageFilter import imageFilter
# from util.helper.video.point import point
# # from util.helper.buffer import timeRingbuffer
# # from ui.gui_test.dialog_active import test_is_running
# from util.helper.enum.enum_settingsPlaceholder import settingsPlaceholder
# from ui.dialog_no_os import no_os_selected_dialog
from util.ocr_tool.imageProcessing import imageProcessing as ImgProc
# from ui.ocr_tool.dialog_active_ocr import test_is_running


class ocr_tool(QDialog):
    __videoStream = None

    # __settingsHandler = settingsHandler()

    __markModeOn = False
    __markedArea = None

    # __timeOld = 0
    # __bufferFps = timeRingbuffer()

    __testBildStream = None
    __ocrTest = None
    __dialogRunning = None
    __testIsRunning = False
    __listDir = os.listdir('C:/Users/Manuel/Pictures/media/pi')

    __originalImage = None
    processingImage = None

    # __brightness = 0
    # __contrast = 0

    __redColorSliderValue = 0
    __greenColorSliderValue = 0
    __blueColorSliderValue = 0
    __thresholdSliderValue = 0

    __originalFilename = None
    __originalExtension = None

    __grayscaleFlag = None

    __outputFormat = None


    def __init__(self):
        super().__init__()

        # self.setupData()

        self.setupUI()

        self.__imageProcessingThread = ImgProc()

        # self.__setupCamera()

        # self.__videoStream.start()

    def __del__(self):
        # self.__videoStream.stop()
        pass

    def setupUI(self):
        # logger.addLog(logType=logTypes.INFO, text='Setup ocr-tool ui.')

        # Layouts
        # self.__styleSheets = stylesheets()

        self.__verticalMainLayout = QVBoxLayout(self) # menubar and horizointalLayoutScreen are added here

        self.__horizontalLayout_Screen = QHBoxLayout() # any button, slider , dropdown and label image (displaying the chosen image) is added here

        # layouts slider and labels
        self.__verticalLayout_RedColorSlider = QVBoxLayout()
        self.__verticalLayout_GreenColorSlider = QVBoxLayout()
        self.__verticalLayout_BlueColorSlider = QVBoxLayout()

        self.__horizontalLayout_thresholdSliderAndLabel = QHBoxLayout()

        self.__horizontalLayout_SliderAndIcons = QHBoxLayout() # add slider and their labels here

        self.__verticalLayout_ButtonGrayscale = QVBoxLayout()
        self.__verticalLayout_ButtonBinary = QVBoxLayout()
        self.__verticalLayout_ButtonCanny = QVBoxLayout()
        self.__verticalLayout_ButtonProcessing = QVBoxLayout()

        self.__horizontalLayout_Buttons = QHBoxLayout() # add Buttons and their labels here

        self.__verticalLayout_ButtonsSlidersDropdown = QVBoxLayout() # add layout sliderandicons and layout buttons here
        
        # Buttons
        self._grayscaleButton = QPushButton()
        self._grayscaleButton.setCheckable(True)
        self._grayscaleButton.pressed.connect(self.__set_grayscaleButton)
        self._grayscaleButton.setText("Grayscale")

        self._binaryButton = QPushButton()
        self._binaryButton.setCheckable(True)
        self._binaryButton.setEnabled(False)
        self._binaryButton.setText("Black and White")

        self._cannyButton = QPushButton()
        self._cannyButton.setCheckable(True)
        self._cannyButton.pressed.connect(self.__set_cannyButton)
        self._cannyButton.setText("Edge Detection")

        self._processingButton = QPushButton()
        self._processingButton.setEnabled(False)
        self._processingButton.clicked.connect(self.__update_values)
        self._processingButton.setText('PROCESS IMAGE')

        # Label
        # self.__labelVideo = QLabel()
        # self.__labelVideo.setPixmap(QPixmap(others.getPathImg() + 'testpicture.jpg').scaled(int(pyautogui.size().width * 0.9),
        #                                                                                  int(pyautogui.size().height * 0.9),
        #                                                                                  QtCore.Qt.KeepAspectRatio))
        self.__labelImage = QLabel()
        self.__labelImage.setPixmap(QPixmap(others.getPathImg() + 'testpicture.jpg').scaled(int(pyautogui.size().width * 0.9),
                                                                                         int(pyautogui.size().height * 0.9),
                                                                                         QtCore.Qt.KeepAspectRatio))
        
        # self.__labelBrightness = QLabel()
        # self.__labelBrightness.setText(str(self.__brightness))

        # self.__labelContrast = QLabel()
        # self.__labelContrast.setText(str(self.__contrast))
        self._labelGrayScaleButtonText = QLabel()
        self._labelGrayScaleButtonText.setText("Grayscale")

        self._labelBinaryButtonText = QLabel()
        self._labelBinaryButtonText.setText("Black and White")

        self._labelCannyButtonText = QLabel()
        self._labelCannyButtonText.setText("Edge Detection")

        self.__labelRedColorSlider = QLabel()
        self.__labelRedColorSlider.setText(str(self.__blueColorSliderValue))
        self.__labelRedColorSliderText = QLabel()
        self.__labelRedColorSliderText.setText('BLUE')

        self.__labelGreenColorSlider = QLabel()
        self.__labelGreenColorSlider.setText(str(self.__greenColorSliderValue))
        self.__labelGreenColorSliderText = QLabel()
        self.__labelGreenColorSliderText.setText('GREEN')

        self.__labelBlueColorSlider = QLabel()
        self.__labelBlueColorSlider.setText(str(self.__redColorSliderValue))
        self.__labelBlueColorSliderText = QLabel()
        self.__labelBlueColorSliderText.setText('RED')

        self.__labelthresholdSlider = QLabel()
        self.__labelthresholdSlider.setText(str(self.__thresholdSliderValue))
        self.__labelthresholdSliderText = QLabel()
        self.__labelthresholdSliderText.setText('Threshold')

        # Sliders
        self.__redColorSlider = QSlider(Qt.Vertical)
        self.__redColorSlider.setMinimum(-255)
        self.__redColorSlider.setMaximum(255)
        self.__redColorSlider.setValue(0)
        self.__redColorSlider.setTickInterval(51)
        self.__redColorSlider.singleStep()
        self.__redColorSlider.setValue(self.__redColorSliderValue)
        self.__redColorSlider.valueChanged.connect(self.__redColorSlider_valueChanged)

        self.__greenColorSlider = QSlider(Qt.Vertical)
        self.__greenColorSlider.setMinimum(-255)
        self.__greenColorSlider.setMaximum(255)
        self.__greenColorSlider.setValue(0)
        self.__greenColorSlider.setTickInterval(51)
        self.__greenColorSlider.singleStep()
        self.__greenColorSlider.setValue(self.__greenColorSliderValue)
        self.__greenColorSlider.valueChanged.connect(self.__greenColorSlider_valueChanged)

        self.__blueColorSlider = QSlider(Qt.Vertical)
        self.__blueColorSlider.setMinimum(-255)
        self.__blueColorSlider.setMaximum(255)
        self.__blueColorSlider.setValue(0)
        self.__blueColorSlider.setTickInterval(51)
        self.__blueColorSlider.singleStep()
        self.__blueColorSlider.setValue(self.__blueColorSliderValue)
        self.__blueColorSlider.valueChanged.connect(self.__blueColorSlider_valueChanged)

        self.__thresholdSlider = QSlider(Qt.Horizontal)
        self.__thresholdSlider.setMaximum(255)
        self.__thresholdSlider.setValue(0)
        self.__thresholdSlider.setTickInterval(51)
        self.__thresholdSlider.singleStep()
        self.__thresholdSlider.setValue(self.__thresholdSliderValue)
        self.__thresholdSlider.valueChanged.connect(self.__thresholdSlider_valueChanged)

        # Assembling layout
        self.__horizontalLayout_Screen.addItem(QSpacerItem(5, 5, QSizePolicy.Expanding, QSizePolicy.Minimum))
        # self.__horizontalLayout_Screen.addWidget(self.__labelVideo)
        self.__horizontalLayout_Screen.addWidget(self.__labelImage)
        self.__horizontalLayout_Screen.addItem(QSpacerItem(5, 5, QSizePolicy.Expanding, QSizePolicy.Minimum))

        self.__verticalLayout_ButtonProcessing.addWidget(self._processingButton)
        self.__verticalLayout_ButtonProcessing.setAlignment(Qt.AlignCenter)

        self.__verticalLayout_ButtonCanny.addWidget(self._labelBinaryButtonText)
        self.__verticalLayout_ButtonCanny.addWidget(self._cannyButton)
        self.__verticalLayout_ButtonCanny.setAlignment(Qt.AlignCenter)

        self.__verticalLayout_ButtonBinary.addWidget(self._labelBinaryButtonText)
        self.__verticalLayout_ButtonBinary.addWidget(self._binaryButton)
        self.__verticalLayout_ButtonBinary.setAlignment(Qt.AlignCenter)

        self.__verticalLayout_ButtonGrayscale.addWidget(self._labelGrayScaleButtonText)
        self.__verticalLayout_ButtonGrayscale.addWidget(self._grayscaleButton)
        self.__verticalLayout_ButtonGrayscale.setAlignment(Qt.AlignCenter)

        self.__horizontalLayout_Buttons.addLayout(self.__verticalLayout_ButtonGrayscale)
        self.__horizontalLayout_Buttons.addLayout(self.__verticalLayout_ButtonBinary)
        self.__horizontalLayout_Buttons.addLayout(self.__verticalLayout_ButtonCanny)
        self.__horizontalLayout_Buttons.addLayout(self.__verticalLayout_ButtonProcessing)

        self.__horizontalLayout_thresholdSliderAndLabel.addWidget(self.__labelthresholdSliderText)
        self.__horizontalLayout_thresholdSliderAndLabel.addWidget(self.__labelthresholdSlider)
        self.__horizontalLayout_thresholdSliderAndLabel.addWidget(self.__thresholdSlider)
        self.__horizontalLayout_thresholdSliderAndLabel.setAlignment(Qt.AlignCenter)
      
        self.__verticalLayout_RedColorSlider.addWidget(self.__labelRedColorSliderText)
        self.__verticalLayout_RedColorSlider.addWidget(self.__labelRedColorSlider)
        self.__verticalLayout_RedColorSlider.addWidget(self.__redColorSlider)
        self.__verticalLayout_RedColorSlider.setAlignment(Qt.AlignCenter)
     
        self.__verticalLayout_GreenColorSlider.addWidget(self.__labelGreenColorSliderText)
        self.__verticalLayout_GreenColorSlider.addWidget(self.__labelGreenColorSlider)
        self.__verticalLayout_GreenColorSlider.addWidget(self.__greenColorSlider)
        self.__verticalLayout_GreenColorSlider.setAlignment(Qt.AlignCenter)

        self.__verticalLayout_BlueColorSlider.addWidget(self.__labelBlueColorSliderText)
        self.__verticalLayout_BlueColorSlider.addWidget(self.__labelBlueColorSlider)     
        self.__verticalLayout_BlueColorSlider.addWidget(self.__blueColorSlider)
        self.__verticalLayout_BlueColorSlider.setAlignment(Qt.AlignCenter)

        # self.__horizontalLayout_SliderAndIcons.addLayout(self.__verticalLayout_Brightness)
        # self.__horizontalLayout_SliderAndIcons.addLayout(self.__verticalLayout_Contrast)
        self.__horizontalLayout_SliderAndIcons.addLayout(self.__verticalLayout_RedColorSlider)
        self.__horizontalLayout_SliderAndIcons.addLayout(self.__verticalLayout_GreenColorSlider)
        self.__horizontalLayout_SliderAndIcons.addLayout(self.__verticalLayout_BlueColorSlider)

        self.__verticalLayout_ButtonsSlidersDropdown.addLayout(self.__horizontalLayout_Buttons)
        self.__verticalLayout_ButtonsSlidersDropdown.addLayout(self.__horizontalLayout_thresholdSliderAndLabel)
        self.__verticalLayout_ButtonsSlidersDropdown.addLayout(self.__horizontalLayout_SliderAndIcons)

        self.__verticalMainLayout.addItem(QSpacerItem(5, 5, QSizePolicy.Minimum, QSizePolicy.Expanding))
        self.__horizontalLayout_Screen.addLayout(self.__verticalLayout_ButtonsSlidersDropdown)
        self.__verticalMainLayout.addItem(QSpacerItem(5, 5, QSizePolicy.Minimum, QSizePolicy.Expanding))

        self.__verticalMainLayout.addItem(QSpacerItem(5, 5, QSizePolicy.Minimum, QSizePolicy.Expanding))
        self.__verticalMainLayout.addLayout(self.__horizontalLayout_Screen)
        self.__verticalMainLayout.addItem(QSpacerItem(5, 5, QSizePolicy.Minimum, QSizePolicy.Expanding))

        # Add menubar
        self.setupMenuBar()

    def setupMenuBar(self):
        # self.__styleSheets = stylesheets()

        # Icons
        # self.__iconStart = QIcon(others.getPathImg() + 'Start.svg')
        # self.__iconStop = QIcon(others.getPathImg() + 'Stop.svg')
        self.__iconOpenImage = QIcon(others.getPathImg() + 'folder.png')
        self.__iconSaveImage =QIcon(others.getPathImg() + 'icon_save.png')
        # self.__iconProtocolSettings = QIcon(others.getPathImg() + 'DocumentSettings.svg')
        # self.__iconMarker = QIcon(others.getPathImg() + 'Pen.png')
        # self.__iconRubber = QIcon(others.getPathImg() + 'rubber.png')
        self.__iconClose = QIcon(others.getPathImg() + 'close.png')
        # self.__iconMarkerPressed = QIcon(others.getPathImg() + 'PenPressed.png')
        # self.__iconOpenImage = QIcon(others.getPathImg() + 'folder.png')

        # Actions
        # self.__actionStartTest = QAction('Start')
        # self.__actionStartTest.setIcon(self.__iconStart)
        # self.__actionStartTest.triggered.connect(self.__actionStartTest_clicked)

        self.__actionOpenImage = QAction('Open Image')
        self.__actionOpenImage.setIcon(self.__iconOpenImage)
        self.__actionOpenImage.triggered.connect(self.__actionOpenImage_clicked)

        self.__actionSaveImage = QAction('Save Image')
        self.__actionSaveImage.setIcon(self.__iconSaveImage)
        self.__actionSaveImage.triggered.connect(self.__actionSaveImage_clicked)

        # self.__actionSettings = QAction('Settings')
        # self.__actionSettings.setIcon(self.__iconProtocolSettings)
        # self.__actionSettings.triggered.connect(self.__actionSettings_clicked)

        # self.__actionDrawArea = QToolButton(self)
        # self.__actionDrawArea.setIcon(self.__iconMarker)
        # self.__actionDrawArea.setCheckable(True)
        # self.__actionDrawArea.triggered.connect(self.__actionDrawArea_clicked)

        # self.__actionDeleteArea = QAction('Delete Area')
        # self.__actionDeleteArea.setIcon(self.__iconRubber)
        # self.__actionDeleteArea.triggered.connect(self.__actionDeleteArea_clicked)

        self.__actionClose = QAction('Close')
        self.__actionClose.setIcon(self.__iconClose)
        self.__actionClose.triggered.connect(self.__actionClose_clicked)     

        # self.__menuBar = QMenuBar(self)
        # self.__menuBar.setGeometry(QRect(0, 0, QApplication.primaryScreen().size().width(), 25))
        # ToolBar
        self.__toolBar = QToolBar(self)
        self.__toolBar.setGeometry(QRect(10, 5, QApplication.primaryScreen().size().width(), 30))
        self.__toolBar.addAction(self.__actionOpenImage)
        self.__toolBar.addAction(self.__actionSaveImage)
        self.__toolBar.addAction(self.__actionClose)

    def __actionOpenImage_clicked(self):
        self.__originalImage, _ = QFileDialog.getOpenFileName(self, "Open Image", "/home", "Image Files (*.png *.jpg *.bmp *.jpeg *.ppm *.xpm *.xbm )")

        # print(self.__originalImage)
        self.__originalFilename = os.path.basename(self.__originalImage.split('.')[0])
        self.__originalExtension = os.path.basename(self.__originalImage.split('.')[1])
        # print(self.__originalFilename)
        # print(self.__originalExtension)

        self.processingImage = cv2.imread(self.__originalImage)
        # cv2.imshow('loaded', self.processingImage)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
        self.__processingQImage = QImage(self.processingImage, self.processingImage.shape[0], self.processingImage.shape[1], QImage.Format_RGB888).rgbSwapped()
        self.__labelImage.setPixmap(QPixmap(self.__processingQImage).scaled(int(pyautogui.size().width * 0.9),
                                                                                         int(pyautogui.size().height * 0.9),
                                                                                         QtCore.Qt.KeepAspectRatio))

        self._processingButton.setEnabled(True)

    def __actionSaveImage_clicked(self):
        filename = QFileDialog.getSaveFileName(self, "Save Image",self.__originalFilename + '_img_proc',self.__originalExtension)

        cv2.imwrite(filename[0]+'.'+self.__originalExtension, self.processingImage) # saving the image

    def __set_grayscaleButton(self):
        if self._grayscaleButton.isChecked():
            self._binaryButton.setEnabled(False)

        if not self._grayscaleButton.isChecked():
            self._binaryButton.setEnabled(True)

    def __set_cannyButton(self):
        if not self._cannyButton.isChecked():
            self._grayscaleButton.setEnabled(False)
            self._binaryButton.setEnabled(False)

        if self._cannyButton.isChecked():
            self._grayscaleButton.setEnabled(True)         
            self._grayscaleButton.setChecked(False)

    def __update_labelImage(self):
        if self._grayscaleButton.isChecked() or self._cannyButton.isChecked():
            self.__outputFormat = QImage.Format_Grayscale8
            self.processingQImage = QImage(self.processingImage, self.processingImage.shape[1], self.processingImage.shape[0], self.__outputFormat)

        else:
            self.__outputFormat = QImage.Format_RGB888
            self.processingQImage = QImage(self.processingImage, self.processingImage.shape[1], self.processingImage.shape[0], self.__outputFormat).rgbSwapped()
        
        # cv2.imshow('update', self.processingImage)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()

        self.__labelImage.setPixmap(QPixmap(self.processingQImage).scaled(int(pyautogui.size().width * 0.9),
                                                                                         int(pyautogui.size().height * 0.9),
                                                                                         QtCore.Qt.KeepAspectRatio))

    @pyqtSlot()
    def __update_values(self):
        self.__imageProcessingThread.grayscaleFlag = self._grayscaleButton.isChecked()
        self.__imageProcessingThread.binaryFlag = self._binaryButton.isChecked()
        self.__imageProcessingThread.cannyFlag = self._cannyButton.isChecked()
        self.__imageProcessingThread.redValue = self.__redColorSliderValue
        self.__imageProcessingThread.greenValue = self.__greenColorSliderValue
        self.__imageProcessingThread.blueValue = self.__blueColorSliderValue
        self.__imageProcessingThread.thresholdValue = self.__thresholdSliderValue
        self.__imageProcessingThread.image = cv2.imread(self.__originalImage)
        self.processingImage = self.__imageProcessingThread.processing()
        # cv2.imshow('update values return', self.processingImage)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
        self.__update_labelImage()
        

    def __redColorSlider_valueChanged(self, value):
        # logger.addLog(logType=logTypes.INFO, text=('Value of RedColorSlider: ' + str(value)))
        self.__redColorSliderValue = value
        self.__labelRedColorSlider.setText(str(self.__redColorSliderValue))

    def __greenColorSlider_valueChanged(self, value):
        # logger.addLog(logType=logTypes.INFO, text=('Value of GreenColorSlider: ' + str(value)))
        self.__greenColorSliderValue = value
        self.__labelGreenColorSlider.setText(str(self.__greenColorSliderValue))

    def __blueColorSlider_valueChanged(self, value):
        # logger.addLog(logType=logTypes.INFO, text=('Value of BlueColorSlider: ' + str(value)))
        self.__blueColorSliderValue = value
        self.__labelBlueColorSlider.setText(str(self.__blueColorSliderValue))

    def __thresholdSlider_valueChanged(self, value):
        # logger.addLog(logType=logTypes.INFO, text=('Value of thresholdSlider: ' + str(value)))
        self.__thresholdSliderValue = value
        self.__labelthresholdSlider.setText(str(self.__thresholdSliderValue))

    def __actionClose_clicked(self):
        # logger.addLog(logType=logTypes.INFO, text='Open dialog \'Close\'.')
        dialog_close = dialogClose()

        if dialog_close.closeApplication:
            # self.__videoStream.stop()
            self.close()


    # @pyqtSlot(np.ndarray)
    # def __updateImage(self, cv_img):
    #     # if self.__markedArea is not None:
    #     #     self.drawArea(cv_img)
    #     #     # cv2.imshow('cv_img', cv_img)
    #     #     # cv2.waitKey(20)

    #     # else:
    #     #     self.__labelVideo.setPixmap(self.__convert_cv_qt(cv_img))

    #     # Calculate fps
    #     # timeNew = time()
    #     # tDiff = (timeNew - self.__timeOld)
    #     # if tDiff > 0.0:
    #     #     self.__bufferFps.addValue((1 / tDiff))

    #     # self.__timeOld = timeNew

    #     self.__labelImage.setPixmap(self.__convert_cv_qt(cv_img))

    # @staticmethod
    # def __convert_cv_qt(cv_img):
    #     height, width, channel = cv_img.shape
    #     bytesPerLine = 3 * width
    #     qImg = QImage(cv_img.data, width, height, bytesPerLine, QImage.Format_RGB888).rgbSwapped()

    #     if others.isTargetSystem():
    #         return QPixmap(qImg).scaled(440, 293)

    #     return QPixmap(qImg)  # .scaled(480, 320)

    # def drawArea(self, cv_img):
    #     pxmp = self.__convert_cv_qt(cv_img)
    #     painter = QPainter(pxmp)

    #     penRectangle = QPen(Qt.red)
    #     penRectangle.setWidth(3)

    #     # pos = imageFilter.getRealFilterPosition(self.__getPositionOfLabel(), self.__markedArea, (1280, 720))
    #     pos = rectangle()
    #     pos.x0 = self.__markedArea.x0 - self.__labelVideo.geometry().x()
    #     pos.y0 = self.__markedArea.y0 - self.__labelVideo.geometry().y()
    #     pos.x1 = self.__markedArea.x1 - self.__labelVideo.geometry().x()
    #     pos.y1 = self.__markedArea.y1 - self.__labelVideo.geometry().y()

    #     painter.setPen(penRectangle)

    #     painter.drawRect(pos.x0, pos.y0, pos.getWidth(), pos.getHeight())

    #     self.__labelVideo.setPixmap(pxmp)

    #     painter.end()

    # def __getPositionOfLabel(self):
    #     rect = rectangle()
    #     rect.x0 = self.__labelVideo.x()
    #     rect.y0 = self.__labelVideo.y()
    #     rect.setWidth(self.__labelVideo.width())
    #     rect.setHeight(self.__labelVideo.height())

    #     return rect

    # def mouseMoveEvent(self, a0: QtGui.QMouseEvent) -> None:
    #     if self.__actionDrawArea.isChecked() and self.__mousePressed:
    #         # Coloring area which should be marked while marking
    #         actualArea = rectangle()
    #         actualArea.x0 = self.__p0[0]
    #         actualArea.y0 = self.__p0[1]
    #         actualArea.x1 = a0.x()
    #         actualArea.y1 = a0.y()

            # self.__markedArea = actualArea

    # def mousePressEvent(self, a0: QtGui.QMouseEvent) -> None:
    #     if self.__actionDrawArea.isChecked():
    #         self.__mousePressed = True
    #         print('Clicked at: ' + str(a0.x()) + '/' + str(a0.y()))
    #         self.__p0 = (a0.x(), a0.y())

    #     elif self.__actionDeleteArea.isChecked():
    #         # Erase marked area
    #         pMouseClick = point(a0.x(), a0.y())
    #         if imageFilter.isPointInArea(self.__getPositionOfLabel(), self.__markedArea, (1280, 720), pMouseClick):
    #             self.__markedArea = None
    #             self.__actionDeleteArea.setCheckable(False)
    #             logger.addLog(logType=logTypes.SUCCESS, text='Area erased.')

    # def mouseReleaseEvent(self, a0: QtGui.QMouseEvent) -> None:
    #     self.__mousePressed = False
    #     if self.__actionDrawArea.isChecked():
    #         print('Mouse released at: ' + str(a0.x()) + '|' + str(a0.y()))
    #         self.__p1 = a0

    #         rec = rectangle()
    #         rec.x0 = self.__p0[0]
    #         rec.y0 = self.__p0[1]
    #         rec.x1 = self.__p1.x()
    #         rec.y1 = self.__p1.y()

    #         print('rectangle: ' + str(rec.x0) + '|' + str(rec.y0) + ' , ' + str(rec.x1) + '|' + str(rec.y1))


    #         self.__actionDrawArea.setChecked(False)

    #         self.__markedArea = rec

    #         self.__actionDeleteArea.setCheckable(True)

    #         qRec = QRect(100, 100, 200, 200)
    #         pix = QPixmap(self.rect().size())
    #         pix.fill(Qt.white)

    #         begin, end = QPoint(), QPoint()
    #         begin.x = 100
    #         begin.y = 100

    #         end.x = 300
    #         end.y = 300


    #         self.painter = QPainter(self)
    #         self.painter.drawPixmap(QPoint(), pix)

    # def __startOCRTest(self):
    #     logger.addLog(logType=logTypes.INFO, text='Start OCR test.')
    #     # if self.__videoStream is not None:
    #     #     self.__stopVideoStream()

    #     self.__testIsRunning = True
    #     self.__actionStartTest.setIcon(self.__iconStop)

    #     # Initialize ocr test
    #     # self.__ocrTest = motion_detection_light(others.getPathStorage(), self.__settingsHandler.os)
    #     self.__ocrTest = ocr()
    #     # self.__guiTest.filterPosition = self.posFilterInImage
    #     if self.__markedArea != None:
    #         fPos = imageFilter.getRealFilterPosition(self.__getPositionOfLabel(), self.__markedArea, (1280, 720))

    #         logger.addLog(logType=logTypes.INFO, text='Set real filter position in image to: '  + '\t\t\t' + 
    #                                                 'x0|y0 = ' + str(fPos.x0) + '|' + str(fPos.y0) + ', ' +
    #                                                 'x1|y1 = ' + str(fPos.x1) + '|' + str(fPos.y1) + ', ' +
    #                                                 'width x height = ' + str(fPos.getWidth()) + ' x ' + str(fPos.getHeight()) )

    #         logger.addLog(logType=logTypes.INFO, text='Size of video label: ' + str(self.__labelVideo.size().width()) + ' x ' + 
    #                                                                             str(self.__labelVideo.size().height()) )
    #         # self.__guiTest.filterPosition = imageFilter.getRealFilterPosition(self.__getPositionOfLabel(), self.__markedArea, (1280, 720))
    #         self.__ocrTest.filterPosition = fPos
            
    #     self.__ocrTest.motionDetectionFinished.connect(self.__guiTestFinished)
    #     # self.__ocrTest.change_pixmap_signal.connect(self.__updateImage)
    #     # self.__ocrTest.change_pixmap_signal.connect(self.__updateImage)

    #     self.__dialogRunning = test_is_running()
    #     self.__dialogRunning.set_md_thread(self.__ocrTest)
    #     # self.__ocrTest.cmd_incremented.connect(self.__dialogRunning.update_cmd_counter)
    #     self.__ocrTest.cmd_incremented.connect(self.__dialogRunning.updateTimer())
    #     self.__dialogRunning.dialog_running_start()

    #     # Start gui test
    #     self.__ocrTest.start()

    # def __stopGuiTest(self):
    #     logger.addLog(logType=logTypes.INFO, text='Stop OCR test.')
    #     if self.__testBildStream is not None:
    #         self.__stopTestBildStream()

    #     if self.__ocrTest is not None:
    #         self.__ocrTest = None

    #     self.__testIsRunning = False
    #     self.__actionStartTest.setIcon(self.__iconStart)

    # def __stopVideoStream(self):
    #     logger.addLog(logType=logTypes.INFO, text='Stop video stream.')
    #     self.__videoStream.stop()
    #     self.__videoStream.wait()
    #     self.__videoStream = None

    # def __guiTestFinished(self):
    #     self.__actionStartTest.setIcon(self.__iconStart)
    #     logger.addLog(logType=logTypes.INFO, text='OCR test finished.')

    #     if self.__ocrTest is not None:
    #         self.__ocrTest = None

    #     self.__stopGuiTest()
    #     self.__startVideoStream()

    # def __startVideoStream(self):
    #     logger.addLog(logType=logTypes.INFO, text='Start video stream.')
    #     self.__videoStream = videoStream()
    #     self.__videoStream.signalChangePixmap.connect(self.__updateImage)
    #     self.__videoStream.start()

    # def __sliderBrightness_valueChanged(self, value):
    #     logger.addLog(logType=logTypes.INFO, text=('Value of brightness: ' + str(value)))
    #     self.__brightness = value
    #     self.__labelBrightness.setText(str(self.__brightness))
    #     # self.__setBrightnessIn4L2(self.__brightness)

    # def __sliderContrast_valueChanged(self, value):
    #     logger.addLog(logType=logTypes.INFO, text=('Value of contrast: ' + str(value)))
    #     self.__contrast = value
    #     self.__labelContrast.setText(str(self.__contrast))
    #     # self.__setContrastInV4L2(self.__contrast)
    
