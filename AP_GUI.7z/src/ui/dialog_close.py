from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QHBoxLayout

from ui.helper.styles import stylesheets
# from util.helper.enum.enum_logTypes import logTypes
# from util.helper.logger import logger


class dialogClose(QDialog):
    """
    Dialog for closing test tool interface (guitest or networktest)
    """
    __styleSheets = stylesheets()
    __verticalMainLayout = None
    __horizontalLayoutButtons = None
    __labelQuestion = None
    __buttonYes = None
    __buttonNo = None

    _closeApplication = False

    def __init__(self):
        """
        Constructor
        """
        super().__init__()

        self.__setupUI()

        self.showFullScreen()
        self.exec_()

    def __del__(self):
        pass

    def __setupUI(self):
        """
        For set up UI of closing tool dialog
        """
        # Layout
        self.__verticalMainLayout = QVBoxLayout(self)
        self.__horizontalLayoutButtons = QHBoxLayout()

        # Label
        self.__labelQuestion = QLabel(self)
        self.__labelQuestion.setText('Close application?')
        self.__labelQuestion.setFont(self.__styleSheets.fontTitle)

        # Buttons
        self.__buttonYes = QPushButton(self)
        self.__buttonYes.setObjectName('buttonYes')
        self.__buttonYes.setText('Yes')
        self.__buttonYes.setFont(self.__styleSheets.fontButtonsMegaLarge)
        self.__buttonYes.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        self.__buttonYes.setStyleSheet(self.__styleSheets.btn_released)
        self.__buttonYes.pressed.connect(self.__buttonYes_pressed)
        self.__buttonYes.released.connect(self.__buttonYes_released)

        self.__buttonNo = QPushButton(self)
        self.__buttonNo.setObjectName('buttonNo')
        self.__buttonNo.setText('No')
        self.__buttonNo.setFont(self.__styleSheets.fontButtonsMegaLarge)
        self.__buttonNo.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        self.__buttonNo.setStyleSheet(self.__styleSheets.btn_released)
        self.__buttonNo.pressed.connect(self.__buttonNo_pressed)
        self.__buttonNo.released.connect(self.__buttonNo_released)

        self.__horizontalLayoutButtons.addWidget(self.__buttonYes)
        self.__horizontalLayoutButtons.addWidget(self.__buttonNo)
        self.__horizontalLayoutButtons.setAlignment(Qt.AlignCenter)

        self.__verticalMainLayout.addWidget(self.__labelQuestion)
        self.__verticalMainLayout.addLayout(self.__horizontalLayoutButtons)
        self.__verticalMainLayout.setAlignment(Qt.AlignCenter)

    def __buttonYes_pressed(self):
        self.__buttonYes.setStyleSheet(self.__styleSheets.btn_pressed)

    def __buttonYes_released(self):
        self.__buttonYes.setStyleSheet(self.__styleSheets.btn_released)
        self._closeApplication = True
        self.close()

    def __buttonNo_pressed(self):
        self.__buttonNo.setStyleSheet(self.__styleSheets.btn_pressed)

    def __buttonNo_released(self):
        self.__buttonNo.setStyleSheet(self.__styleSheets.btn_released)
        self.close()

    @property
    def closeApplication(self):
        return self._closeApplication

    @closeApplication.setter
    def closeApplication(self, value):
        if isinstance(value, bool):
            self._closeApplication = value

    @closeApplication.deleter
    def closeApplication(self):
        del self._closeApplication
