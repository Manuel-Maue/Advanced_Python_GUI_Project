from PyQt5 import QtCore
from PyQt5.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout, QAction, QApplication, QToolBar, QFileDialog, QSlider
from PyQt5.QtGui import QPixmap, QImage, QIcon
from PyQt5.QtCore import pyqtSlot, QRect, Qt

import pyautogui
import os
import cv2

from ui.dialog_close import dialogClose
import util.helper.others as others
from util.image_processing.imageProcessing import imageProcessing as ImgProc

class image_processing_dialog(QDialog):

    __originalImage = None
    processingImage = None

    __redColorSliderValue = 0
    __greenColorSliderValue = 0
    __blueColorSliderValue = 0
    __thresholdSliderValue = 0

    __originalFilename = None
    __originalExtension = None

    __outputFormat = None


    def __init__(self):
        super().__init__()

        self.setupUI()

        self.__imageProcessingThread = ImgProc()

    def setupUI(self):
        # Layouts
        self.__verticalMainLayout = QVBoxLayout(self) # menubar and horizointalLayoutScreen are added here

        self.__horizontalLayout_Screen = QHBoxLayout() # any button, slider , dropdown and label image (displaying the chosen image) is added here

        # layouts slider and labels
        self.__verticalLayout_RedColorSlider = QVBoxLayout()
        self.__verticalLayout_GreenColorSlider = QVBoxLayout()
        self.__verticalLayout_BlueColorSlider = QVBoxLayout()

        self.__horizontalLayout_thresholdSliderAndLabel = QHBoxLayout()

        self.__horizontalLayout_SliderAndIcons = QHBoxLayout() # add slider and their labels here

        self.__verticalLayout_ButtonGrayscale = QVBoxLayout()
        self.__verticalLayout_ButtonBinary = QVBoxLayout()
        self.__verticalLayout_ButtonCanny = QVBoxLayout()
        self.__verticalLayout_ButtonProcessing = QVBoxLayout()

        self.__horizontalLayout_Buttons = QHBoxLayout() # add Buttons and their labels here

        self.__verticalLayout_ButtonsSlidersDropdown = QVBoxLayout() # add layout sliderandicons and layout buttons here
        
        # Buttons
        self._grayscaleButton = QPushButton()
        self._grayscaleButton.setCheckable(True)
        self._grayscaleButton.pressed.connect(self.__set_grayscaleButton)
        self._grayscaleButton.setText("Grayscale")

        self._binaryButton = QPushButton()
        self._binaryButton.setCheckable(True)
        self._binaryButton.setEnabled(False)
        self._binaryButton.setText("Black and White")

        self._cannyButton = QPushButton()
        self._cannyButton.setCheckable(True)
        self._cannyButton.pressed.connect(self.__set_cannyButton)
        self._cannyButton.setText("Edge Detection")

        self._processingButton = QPushButton()
        self._processingButton.setEnabled(False)
        self._processingButton.clicked.connect(self.__update_values)
        self._processingButton.setText('PROCESS IMAGE')

        # Label
        # starting image to be displayed
        self.__labelImage = QLabel()
        self.__labelImage.setPixmap(QPixmap(others.getPathImg() + 'testpicture.jpg').scaled(int(pyautogui.size().width * 0.9),
                                                                                         int(pyautogui.size().height * 0.9),
                                                                                         QtCore.Qt.KeepAspectRatio))
        
        self._labelGrayScaleButtonText = QLabel()
        self._labelGrayScaleButtonText.setText("Grayscale")

        self._labelBinaryButtonText = QLabel()
        self._labelBinaryButtonText.setText("Black and White")

        self._labelCannyButtonText = QLabel()
        self._labelCannyButtonText.setText("Edge Detection")

        self.__labelRedColorSlider = QLabel()
        self.__labelRedColorSlider.setText(str(self.__blueColorSliderValue))
        self.__labelRedColorSliderText = QLabel()
        self.__labelRedColorSliderText.setText('BLUE')

        self.__labelGreenColorSlider = QLabel()
        self.__labelGreenColorSlider.setText(str(self.__greenColorSliderValue))
        self.__labelGreenColorSliderText = QLabel()
        self.__labelGreenColorSliderText.setText('GREEN')

        self.__labelBlueColorSlider = QLabel()
        self.__labelBlueColorSlider.setText(str(self.__redColorSliderValue))
        self.__labelBlueColorSliderText = QLabel()
        self.__labelBlueColorSliderText.setText('RED')

        self.__labelthresholdSlider = QLabel()
        self.__labelthresholdSlider.setText(str(self.__thresholdSliderValue))
        self.__labelthresholdSliderText = QLabel()
        self.__labelthresholdSliderText.setText('Threshold')

        # Sliders
        self.__redColorSlider = QSlider(Qt.Vertical)
        self.__redColorSlider.setMinimum(-255)
        self.__redColorSlider.setMaximum(255)
        self.__redColorSlider.setValue(0)
        self.__redColorSlider.setTickInterval(51)
        self.__redColorSlider.singleStep()
        self.__redColorSlider.setValue(self.__redColorSliderValue)
        self.__redColorSlider.valueChanged.connect(self.__redColorSlider_valueChanged)

        self.__greenColorSlider = QSlider(Qt.Vertical)
        self.__greenColorSlider.setMinimum(-255)
        self.__greenColorSlider.setMaximum(255)
        self.__greenColorSlider.setValue(0)
        self.__greenColorSlider.setTickInterval(51)
        self.__greenColorSlider.singleStep()
        self.__greenColorSlider.setValue(self.__greenColorSliderValue)
        self.__greenColorSlider.valueChanged.connect(self.__greenColorSlider_valueChanged)

        self.__blueColorSlider = QSlider(Qt.Vertical)
        self.__blueColorSlider.setMinimum(-255)
        self.__blueColorSlider.setMaximum(255)
        self.__blueColorSlider.setValue(0)
        self.__blueColorSlider.setTickInterval(51)
        self.__blueColorSlider.singleStep()
        self.__blueColorSlider.setValue(self.__blueColorSliderValue)
        self.__blueColorSlider.valueChanged.connect(self.__blueColorSlider_valueChanged)

        self.__thresholdSlider = QSlider(Qt.Horizontal)
        self.__thresholdSlider.setMaximum(255)
        self.__thresholdSlider.setValue(0)
        self.__thresholdSlider.setTickInterval(51)
        self.__thresholdSlider.singleStep()
        self.__thresholdSlider.setValue(self.__thresholdSliderValue)
        self.__thresholdSlider.valueChanged.connect(self.__thresholdSlider_valueChanged)

        # Assembling layout
        self.__horizontalLayout_Screen.addItem(QSpacerItem(5, 5, QSizePolicy.Expanding, QSizePolicy.Minimum))
        self.__horizontalLayout_Screen.addWidget(self.__labelImage)
        self.__horizontalLayout_Screen.addItem(QSpacerItem(5, 5, QSizePolicy.Expanding, QSizePolicy.Minimum))

        self.__verticalLayout_ButtonProcessing.addWidget(self._processingButton)
        self.__verticalLayout_ButtonProcessing.setAlignment(Qt.AlignCenter)

        self.__verticalLayout_ButtonCanny.addWidget(self._labelBinaryButtonText)
        self.__verticalLayout_ButtonCanny.addWidget(self._cannyButton)
        self.__verticalLayout_ButtonCanny.setAlignment(Qt.AlignCenter)

        self.__verticalLayout_ButtonBinary.addWidget(self._labelBinaryButtonText)
        self.__verticalLayout_ButtonBinary.addWidget(self._binaryButton)
        self.__verticalLayout_ButtonBinary.setAlignment(Qt.AlignCenter)

        self.__verticalLayout_ButtonGrayscale.addWidget(self._labelGrayScaleButtonText)
        self.__verticalLayout_ButtonGrayscale.addWidget(self._grayscaleButton)
        self.__verticalLayout_ButtonGrayscale.setAlignment(Qt.AlignCenter)

        self.__horizontalLayout_Buttons.addLayout(self.__verticalLayout_ButtonGrayscale)
        self.__horizontalLayout_Buttons.addLayout(self.__verticalLayout_ButtonBinary)
        self.__horizontalLayout_Buttons.addLayout(self.__verticalLayout_ButtonCanny)
        self.__horizontalLayout_Buttons.addLayout(self.__verticalLayout_ButtonProcessing)

        self.__horizontalLayout_thresholdSliderAndLabel.addWidget(self.__labelthresholdSliderText)
        self.__horizontalLayout_thresholdSliderAndLabel.addWidget(self.__labelthresholdSlider)
        self.__horizontalLayout_thresholdSliderAndLabel.addWidget(self.__thresholdSlider)
        self.__horizontalLayout_thresholdSliderAndLabel.setAlignment(Qt.AlignCenter)
      
        self.__verticalLayout_RedColorSlider.addWidget(self.__labelRedColorSliderText)
        self.__verticalLayout_RedColorSlider.addWidget(self.__labelRedColorSlider)
        self.__verticalLayout_RedColorSlider.addWidget(self.__redColorSlider)
        self.__verticalLayout_RedColorSlider.setAlignment(Qt.AlignCenter)
     
        self.__verticalLayout_GreenColorSlider.addWidget(self.__labelGreenColorSliderText)
        self.__verticalLayout_GreenColorSlider.addWidget(self.__labelGreenColorSlider)
        self.__verticalLayout_GreenColorSlider.addWidget(self.__greenColorSlider)
        self.__verticalLayout_GreenColorSlider.setAlignment(Qt.AlignCenter)

        self.__verticalLayout_BlueColorSlider.addWidget(self.__labelBlueColorSliderText)
        self.__verticalLayout_BlueColorSlider.addWidget(self.__labelBlueColorSlider)     
        self.__verticalLayout_BlueColorSlider.addWidget(self.__blueColorSlider)
        self.__verticalLayout_BlueColorSlider.setAlignment(Qt.AlignCenter)

        self.__horizontalLayout_SliderAndIcons.addLayout(self.__verticalLayout_RedColorSlider)
        self.__horizontalLayout_SliderAndIcons.addLayout(self.__verticalLayout_GreenColorSlider)
        self.__horizontalLayout_SliderAndIcons.addLayout(self.__verticalLayout_BlueColorSlider)

        self.__verticalLayout_ButtonsSlidersDropdown.addLayout(self.__horizontalLayout_Buttons)
        self.__verticalLayout_ButtonsSlidersDropdown.addLayout(self.__horizontalLayout_thresholdSliderAndLabel)
        self.__verticalLayout_ButtonsSlidersDropdown.addLayout(self.__horizontalLayout_SliderAndIcons)

        self.__verticalMainLayout.addItem(QSpacerItem(5, 5, QSizePolicy.Minimum, QSizePolicy.Expanding))
        self.__horizontalLayout_Screen.addLayout(self.__verticalLayout_ButtonsSlidersDropdown)
        self.__verticalMainLayout.addItem(QSpacerItem(5, 5, QSizePolicy.Minimum, QSizePolicy.Expanding))

        self.__verticalMainLayout.addItem(QSpacerItem(5, 5, QSizePolicy.Minimum, QSizePolicy.Expanding))
        self.__verticalMainLayout.addLayout(self.__horizontalLayout_Screen)
        self.__verticalMainLayout.addItem(QSpacerItem(5, 5, QSizePolicy.Minimum, QSizePolicy.Expanding))

        # Add menubar
        self.setupMenuBar()

    def setupMenuBar(self):
        # Icons
        self.__iconOpenImage = QIcon(others.getPathImg() + 'folder.png')
        self.__iconSaveImage =QIcon(others.getPathImg() + 'icon_save.png')
        self.__iconClose = QIcon(others.getPathImg() + 'close.png')

        # Actions
        self.__actionOpenImage = QAction('Open Image')
        self.__actionOpenImage.setIcon(self.__iconOpenImage)
        self.__actionOpenImage.triggered.connect(self.__actionOpenImage_clicked)

        self.__actionSaveImage = QAction('Save Image')
        self.__actionSaveImage.setIcon(self.__iconSaveImage)
        self.__actionSaveImage.triggered.connect(self.__actionSaveImage_clicked)

        self.__actionClose = QAction('Close')
        self.__actionClose.setIcon(self.__iconClose)
        self.__actionClose.triggered.connect(self.__actionClose_clicked)     

        # ToolBar
        self.__toolBar = QToolBar(self)
        self.__toolBar.setGeometry(QRect(10, 5, QApplication.primaryScreen().size().width(), 30))
        self.__toolBar.addAction(self.__actionOpenImage)
        self.__toolBar.addAction(self.__actionSaveImage)
        self.__toolBar.addAction(self.__actionClose)

    def __actionOpenImage_clicked(self):
        '''
        Loading an image into the application.
        Processing will be enabled after loading an image.
        '''
        self.__originalImage, _ = QFileDialog.getOpenFileName(self, "Open Image", "/home", "Image Files (*.png *.jpg *.bmp *.jpeg *.ppm *.xpm *.xbm )")

        # print(self.__originalImage)
        self.__originalFilename = os.path.basename(self.__originalImage.split('.')[0])
        self.__originalExtension = os.path.basename(self.__originalImage.split('.')[1])
        # print(self.__originalFilename)
        # print(self.__originalExtension)

        self.processingImage = cv2.imread(self.__originalImage)
        # cv2.imshow('loaded', self.processingImage)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
        self.__processingQImage = QImage(self.processingImage, self.processingImage.shape[0], self.processingImage.shape[1], QImage.Format_RGB888).rgbSwapped()
        self.__labelImage.setPixmap(QPixmap(self.__processingQImage).scaled(int(pyautogui.size().width * 0.9),
                                                                                         int(pyautogui.size().height * 0.9),
                                                                                         QtCore.Qt.KeepAspectRatio))

        self._processingButton.setEnabled(True)

    def __actionSaveImage_clicked(self):
        '''
        Initializing the saving process.
        '''
        filename = QFileDialog.getSaveFileName(self, "Save Image",self.__originalFilename + '_img_proc',self.__originalExtension)

        cv2.imwrite(filename[0]+'.'+self.__originalExtension, self.processingImage) # saving the image

    def __set_grayscaleButton(self):
        '''
        Seting grayscale for image processing.
        Enabling the binarization button.
        '''
        if self._grayscaleButton.isChecked():
            self._binaryButton.setEnabled(False)

        if not self._grayscaleButton.isChecked():
            self._binaryButton.setEnabled(True)

    def __set_cannyButton(self):
        '''
        Seting edge detection for image processing.
        Disabling grayscale and binarization.
        '''
        if not self._cannyButton.isChecked():
            self._grayscaleButton.setEnabled(False)
            self._binaryButton.setEnabled(False)

        if self._cannyButton.isChecked():
            self._grayscaleButton.setEnabled(True)         
            self._grayscaleButton.setChecked(False)

    def __update_labelImage(self):
        '''
        Presenting the image after processing.
        Checking for the color format for the QImage.
        '''
        if self._grayscaleButton.isChecked() or self._cannyButton.isChecked():
            self.__outputFormat = QImage.Format_Grayscale8
            self.processingQImage = QImage(self.processingImage, self.processingImage.shape[1], self.processingImage.shape[0], self.__outputFormat)

        else:
            self.__outputFormat = QImage.Format_RGB888
            self.processingQImage = QImage(self.processingImage, self.processingImage.shape[1], self.processingImage.shape[0], self.__outputFormat).rgbSwapped()
        
        # cv2.imshow('update', self.processingImage)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()

        self.__labelImage.setPixmap(QPixmap(self.processingQImage).scaled(int(pyautogui.size().width * 0.9),
                                                                                         int(pyautogui.size().height * 0.9),
                                                                                         QtCore.Qt.KeepAspectRatio))

    @pyqtSlot()
    def __update_values(self):
        '''
        Starting the image processing.
        Providing the values and flags for the image processing class.
        '''
        self.__imageProcessingThread.grayscaleFlag = self._grayscaleButton.isChecked()
        self.__imageProcessingThread.binaryFlag = self._binaryButton.isChecked()
        self.__imageProcessingThread.cannyFlag = self._cannyButton.isChecked()
        self.__imageProcessingThread.redValue = self.__redColorSliderValue
        self.__imageProcessingThread.greenValue = self.__greenColorSliderValue
        self.__imageProcessingThread.blueValue = self.__blueColorSliderValue
        self.__imageProcessingThread.thresholdValue = self.__thresholdSliderValue
        self.__imageProcessingThread.image = cv2.imread(self.__originalImage)
        self.processingImage = self.__imageProcessingThread.processing()
        # cv2.imshow('update values return', self.processingImage)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
        self.__update_labelImage()
        

    def __redColorSlider_valueChanged(self, value):
        '''
        changing the red color slider value.
        '''
        self.__redColorSliderValue = value
        self.__labelRedColorSlider.setText(str(self.__redColorSliderValue))

    def __greenColorSlider_valueChanged(self, value):
        '''
        changing the green color slider value.
        '''
        self.__greenColorSliderValue = value
        self.__labelGreenColorSlider.setText(str(self.__greenColorSliderValue))

    def __blueColorSlider_valueChanged(self, value):
        '''
        changing the blue color slider value.
        '''
        self.__blueColorSliderValue = value
        self.__labelBlueColorSlider.setText(str(self.__blueColorSliderValue))

    def __thresholdSlider_valueChanged(self, value):
        '''
        changing the threshold slider value.
        '''
        self.__thresholdSliderValue = value
        self.__labelthresholdSlider.setText(str(self.__thresholdSliderValue))

    def __actionClose_clicked(self):
        '''
        Closing the gui.
        '''
        dialog_close = dialogClose()

        if dialog_close.closeApplication:
            self.close()