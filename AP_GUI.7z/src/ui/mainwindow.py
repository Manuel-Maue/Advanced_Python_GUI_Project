import os

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtWidgets import QMainWindow, QPushButton, QVBoxLayout, QWidget, QApplication, QLabel, QHBoxLayout, \
    QSpacerItem, QSizePolicy

# from ui.dialog_permission import dialog_permission
from ui.dialog_shutdown_reboot import window_shutdown_reboot
# from ui.dialog_update import dialog_update
# from ui.gui_test.dialog_gui_testing import gui_test
from ui.ocr_tool.dialog_ocr_tool import ocr_tool
import ui.helper.styles as styles
# from ui.network_test.dialog_network_testing import network_testing
# from src.util.helper import others, permissions
import util.helper.others as others
# import src.util.helper.permissions as permissions
# from util.helper.enum.enum_logTypes import logTypes
# from util.network_test.ipSettingsHandler import ipSettingsHandler
# from util.helper.logger import logger


class MainWindow(QMainWindow):
    """
    Main window of application.
    """
    __centralWidget = None
    __buttonClose = __buttonStartGUITest = __buttonStartNetworkTest = __buttonShutdownMenu = None
    __iconPTB = None
    __verticalMainLayout = None
    __exec_on_targetsystem = False
    __styleSheets = styles.stylesheets()

    __pathMain = None
    __pathImg = None

    def __init__(self):
        super().__init__()

        self.__pathImg = os.getcwd() + '/img/'
        # logger.newLog()
        # logger.addLog(logType=logTypes.INFO, text=('Current path \'' + str(self.__pathImg) + '\''))

        self.__setupUI()

    def __setupUI(self):
        """
        To set up UI of mainwindow.
        """
        # logger.addLog(logType=logTypes.INFO, text='Initialize mainwindow.')
        self.setObjectName('MainWindow')
        self.setMaximumSize(QApplication.primaryScreen().size())
        # self.setWindowTitle('GUI-Tester')
        self.setWindowTitle('image processing')

        # Icons
        self.__iconOnOff = QIcon(others.getPathImg() + 'OnOff2.svg')
        # Todo: self.__iconUpdate laden

        # Central widget
        self.__centralWidget = QWidget(self)
        self.__centralWidget.setObjectName('centralWidget')
        # self.__centralWidget.setMaximumSize(QApplication.primaryScreen().size())
        self.__centralWidget.setPalette(self.__styleSheets.pal_indian_red)
        self.setCentralWidget(self.__centralWidget)

        # Layouts
        self.__verticalMainLayout = QVBoxLayout(self.__centralWidget)
        self.__verticalMainLayout.setObjectName('verticalMainLayout')

        self.__horizontalLayoutApplications = QHBoxLayout()
        self.__horizontalLayoutApplications.setObjectName('horizontalLayoutApplications')

        self.__horizontalLayoutFooter = QHBoxLayout()
        self.__horizontalLayoutFooter.setObjectName('horizontalLayoutFooter')

        # Labels
        self.__labelTitle = QLabel('Automatic testing tool')
        self.__labelTitle.setFont(self.__styleSheets.fontTitle)

        # Buttons
        # self.__buttonStartGUITest = QPushButton()
        # self.__buttonStartGUITest.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        # self.__buttonStartGUITest.setText('GUI test')
        # self.__buttonStartGUITest.setStyleSheet(self.__styleSheets.btn_released)
        # self.__buttonStartGUITest.setFont(self.__styleSheets.fontButtonsMegaLarge_bold)
        # self.__buttonStartGUITest.pressed.connect(self.__buttonStartGUITestApplication_pressed)
        # self.__buttonStartGUITest.released.connect(self.__buttonStartGUITestApplication_released)

        # self.__buttonStartNetworkTest = QPushButton()
        # self.__buttonStartNetworkTest.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        # self.__buttonStartNetworkTest.setText('Network test')
        # self.__buttonStartNetworkTest.setStyleSheet(self.__styleSheets.btn_released)
        # self.__buttonStartNetworkTest.setFont(self.__styleSheets.fontButtonsMegaLarge_bold)
        # self.__buttonStartNetworkTest.pressed.connect(self.__buttonStartNetworkTestApplication_pressed)
        # self.__buttonStartNetworkTest.released.connect(self.__buttonStartNetworkTestApplication_released)

        self.__buttonShutdownMenu = QPushButton()
        self.__buttonShutdownMenu.setText('Beenden')
        self.__buttonShutdownMenu.setFont(self.__styleSheets.fontButtonsMegaLarge_bold)
        self.__buttonShutdownMenu.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        self.__buttonShutdownMenu.setIcon(self.__iconOnOff)
        self.__buttonShutdownMenu.setIconSize(self.__styleSheets.sizeButtonsMegaLarge)
        self.__buttonShutdownMenu.setStyleSheet(self.__styleSheets.btn_released)
        self.__buttonShutdownMenu.pressed.connect(self.__buttonShutdownMenu_pressed)
        self.__buttonShutdownMenu.released.connect(self.__buttonShutdownMenu_released)

        # self.__buttonUpdate = QPushButton()
        # self.__buttonUpdate.setObjectName('buttonUpdate')
        # self.__buttonUpdate.setText('Update')
        # self.__buttonUpdate.setFont(self.__styleSheets.fontButtonsMegaLarge_bold)
        # self.__buttonUpdate.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        # self.__buttonUpdate.setIconSize(self.__styleSheets.sizeButtonsMegaLarge)
        # self.__buttonUpdate.setStyleSheet(self.__styleSheets.btn_released)
        # self.__buttonUpdate.pressed.connect(self.__buttonUpdate_pressed)
        # self.__buttonUpdate.released.connect(self.__buttonUpdate_released)

        self.__buttonOCRTool = QPushButton()
        self.__buttonOCRTool.setObjectName('buttonOCRTool')
        # self.__buttonOCRTool.setText('OCR-Tool')
        self.__buttonOCRTool.setText('Start')
        self.__buttonOCRTool.setFont(self.__styleSheets.fontButtonsMegaLarge_bold)
        self.__buttonOCRTool.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        self.__buttonOCRTool.setStyleSheet(self.__styleSheets.btn_released)
        self.__buttonOCRTool.pressed.connect(self.__buttonOCRTool_pressed)
        self.__buttonOCRTool.released.connect(self.__buttonOCRTool_released)

        # Icon Label
        # self.__labelIconPTB = QLabel(self.__centralWidget)
        # self.__labelIconPTB.setPixmap(QPixmap(self.__pathImg + 'logo_short.jpg').scaled(self.__styleSheets.sizePTBLogo.width(),
                                                                                        # self.__styleSheets.sizePTBLogo.height(),
                                                                                        # Qt.KeepAspectRatio))
        # self.__labelIconPTB.setFixedSize(self.__styleSheets.sizePTBLogo)

        # Spacer
        self.__verticalSpacer_0 = QSpacerItem(40, 20, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.__verticalSpacer_1 = QSpacerItem(40, 20, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.__horizontalSpacer_0 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.__horizontalSpacer_1 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.__horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        # Assembling layout
        self.__horizontalLayoutApplications.addItem(self.__horizontalSpacer_0)
        self.__horizontalLayoutApplications.addWidget(self.__buttonStartGUITest)
        self.__horizontalLayoutApplications.addWidget(self.__buttonStartNetworkTest)
        self.__horizontalLayoutApplications.addWidget(self.__buttonOCRTool)
        # self.__horizontalLayoutApplications.addWidget(self.__buttonUpdate)
        self.__horizontalLayoutApplications.addWidget(self.__buttonShutdownMenu)
        self.__horizontalLayoutApplications.addItem(self.__horizontalSpacer_1)

        self.__horizontalLayoutFooter.addItem(self.__horizontalSpacer_2)
        # self.__horizontalLayoutFooter.addWidget(self.__labelIconPTB)

        self.__verticalMainLayout.addWidget(self.__labelTitle)
        self.__verticalMainLayout.addItem(self.__verticalSpacer_0)
        self.__verticalMainLayout.addLayout(self.__horizontalLayoutApplications)
        self.__verticalMainLayout.addItem(self.__verticalSpacer_1)
        self.__verticalMainLayout.addLayout(self.__horizontalLayoutFooter)
        self.__verticalMainLayout.setAlignment(Qt.AlignCenter)

        self.setPalette(self.__styleSheets.pal_snow_white)

        # logger.addLog(logType=logTypes.INFO, text='UI initialized.')

    # def __buttonClose_pressed(self):
    #     self.__buttonClose.setStyleSheet(self.__styleSheets.btn_pressed)

    # def __buttonClose_released(self):
    #     self.__buttonClose.setStyleSheet(self.__styleSheets.btn_released)
    #     logger.closeLog()
    #     self.close()

    # def __buttonStartGUITestApplication_pressed(self):
    #     self.__buttonStartGUITest.setStyleSheet(self.__styleSheets.btn_pressed)

    # def __buttonStartGUITestApplication_released(self):
    #     self.__buttonStartGUITest.setStyleSheet(self.__styleSheets.btn_released)
    #     logger.addLog(logType=logTypes.INFO, text='Start gui test.')

    #     dialog_guiTest = gui_test()
    #     dialog_guiTest.showFullScreen()
    #     dialog_guiTest.exec_()

    # def __buttonStartNetworkTestApplication_pressed(self):
    #     self.__buttonStartNetworkTest.setStyleSheet(self.__styleSheets.btn_pressed)

    # def __buttonStartNetworkTestApplication_released(self):
    #     self.__buttonStartNetworkTest.setStyleSheet(self.__styleSheets.btn_released)
    #     logger.addLog(logType=logTypes.INFO, text='Start network test.')

    #     dialog_networkTest = network_testing()
    #     dialog_networkTest.showFullScreen()
    #     dialog_networkTest.exec_()

    def __buttonOCRTool_pressed(self):
        self.__buttonOCRTool.setStyleSheet(self.__styleSheets.btn_pressed)
        
    def __buttonOCRTool_released(self):
        # logger.addLog(logType=logTypes.INFO, text='Open ocr tool')
        self.__buttonOCRTool.setStyleSheet(self.__styleSheets.btn_released)
        
        dialog_ocrTool = ocr_tool()
        dialog_ocrTool.showFullScreen()
        dialog_ocrTool.exec_()

    # def __buttonUpdate_pressed(self):
    #     self.__buttonUpdate.setStyleSheet(self.__styleSheets.btn_pressed)

    # def __buttonUpdate_released(self):
    #     self.__buttonUpdate.setStyleSheet(self.__styleSheets.btn_released)
    #     logger.addLog(logType=logTypes.INFO, text='Opening update dialog.')

    #     # Changing dhcpcd.conf settings to default, for enabling internet connection
    #     if others.isTargetSystem():
    #         pathDHCPCDConfig = '/etc/dhcpcd.conf'
    #         dhcpcdConfigHandle = ipSettingsHandler(pathDHCPCDConfig)
    #         dhcpcdConfigHandle.configurateDefaultNetwork()

        # Request permission
        '''dialogPermissions = dialog_permission()
        dialogPermissions.showFullScreen()
        dialogPermissions.exec_()

        name = dialogPermissions.username
        password = dialogPermissions.password

        permissionChecker = permissions.permissionChecker()
        permissionChecker.username = name
        permissionChecker.password = password

        if dialogPermissions.canceled:
            logger.addLog(logType=logTypes.INFO, text='Getting permissions canceled.')
            return

        if permissionChecker.isPermitted():
            dialogUpdate = dialog_update()
            dialogUpdate.showFullScreen()
            dialogUpdate.exec_()

        else:
            self.__msgBox_noPermissions = QMessageBox()
            self.__msgBox_noPermissions.setWindowTitle('Access denied')
            self.__msgBox_noPermissions.setText('Invalid username and/or password.')
            self.__msgBox_noPermissions.show()
            self.__msgBox_noPermissions.exec_()'''

        # dialogUpdate = dialog_update()
        # dialogUpdate.showFullScreen()
        # dialogUpdate.exec_()

    def __buttonShutdownMenu_pressed(self):
        self.__buttonShutdownMenu.setStyleSheet(self.__styleSheets.btn_pressed)

    def __buttonShutdownMenu_released(self):
        self.__buttonShutdownMenu.setStyleSheet(self.__styleSheets.btn_released)
        # logger.addLog(logType=logTypes.INFO, text='Open shutdown/reboot menu.')

        dialog_shutdownReboot = window_shutdown_reboot()
        dialog_shutdownReboot.showFullScreen()
        dialog_shutdownReboot.exec_()

        if dialog_shutdownReboot.get_close_flag():
            # logger.addLog(logType=logTypes.INFO, text='Close application.')
            self.close()
        else:
            # logger.addLog(logType=logTypes.INFO, text='Abort closing application.')
            pass
