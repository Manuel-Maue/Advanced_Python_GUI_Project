from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QMainWindow, QPushButton, QVBoxLayout, QWidget, QApplication, QLabel, QHBoxLayout, \
    QSpacerItem, QSizePolicy

from ui.dialog_shutdown_reboot import window_shutdown_reboot
from ui.image_processing.dialog_image_processing import image_processing_dialog
import ui.helper.styles as styles
import util.helper.others as others

class MainWindow(QMainWindow):
    """
    Main window of application.
    """
    __centralWidget = None
    __buttonShutdownMenu = None
    __verticalMainLayout = None
    __styleSheets = styles.stylesheets()

    def __init__(self):
        super().__init__()

        self.__setupUI()

    def __setupUI(self):
        """
        To set up UI of mainwindow.
        """
        self.setObjectName('MainWindow')
        self.setMaximumSize(QApplication.primaryScreen().size())
        self.setWindowTitle('image processing')

        # Icons
        self.__iconOnOff = QIcon(others.getPathImg() + 'OnOff2.svg')

        # Central widget
        self.__centralWidget = QWidget(self)
        self.__centralWidget.setObjectName('centralWidget')
        self.__centralWidget.setPalette(self.__styleSheets.pal_indian_red)
        self.setCentralWidget(self.__centralWidget)

        # Layouts
        self.__verticalMainLayout = QVBoxLayout(self.__centralWidget)
        self.__verticalMainLayout.setObjectName('verticalMainLayout')

        self.__horizontalLayoutApplications = QHBoxLayout()
        self.__horizontalLayoutApplications.setObjectName('horizontalLayoutApplications')

        self.__horizontalLayoutFooter = QHBoxLayout()
        self.__horizontalLayoutFooter.setObjectName('horizontalLayoutFooter')

        # Labels
        self.__labelTitle = QLabel('Schubidu Bildbearbeitung')
        self.__labelTitle.setFont(self.__styleSheets.fontTitle)

        # Buttons
        self.__buttonShutdownMenu = QPushButton()
        self.__buttonShutdownMenu.setText('Beenden')
        self.__buttonShutdownMenu.setFont(self.__styleSheets.fontButtonsMegaLarge_bold)
        self.__buttonShutdownMenu.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        self.__buttonShutdownMenu.setIcon(self.__iconOnOff)
        self.__buttonShutdownMenu.setIconSize(self.__styleSheets.sizeButtonsMegaLarge)
        self.__buttonShutdownMenu.setStyleSheet(self.__styleSheets.btn_released)
        self.__buttonShutdownMenu.pressed.connect(self.__buttonShutdownMenu_pressed)
        self.__buttonShutdownMenu.released.connect(self.__buttonShutdownMenu_released)

        self.__buttonStart = QPushButton()
        self.__buttonStart.setObjectName('__buttonStart')
        self.__buttonStart.setText('Start')
        self.__buttonStart.setFont(self.__styleSheets.fontButtonsMegaLarge_bold)
        self.__buttonStart.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        self.__buttonStart.setStyleSheet(self.__styleSheets.btn_released)
        self.__buttonStart.pressed.connect(self.__start_pressed)
        self.__buttonStart.released.connect(self.__start_released)

        # Spacer
        self.__verticalSpacer_0 = QSpacerItem(40, 20, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.__verticalSpacer_1 = QSpacerItem(40, 20, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.__horizontalSpacer_0 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.__horizontalSpacer_1 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.__horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        # Assembling layout
        self.__horizontalLayoutApplications.addItem(self.__horizontalSpacer_0)
        self.__horizontalLayoutApplications.addWidget(self.__buttonStart)
        self.__horizontalLayoutApplications.addWidget(self.__buttonShutdownMenu)
        self.__horizontalLayoutApplications.addItem(self.__horizontalSpacer_1)

        self.__horizontalLayoutFooter.addItem(self.__horizontalSpacer_2)

        self.__verticalMainLayout.addWidget(self.__labelTitle)
        self.__verticalMainLayout.addItem(self.__verticalSpacer_0)
        self.__verticalMainLayout.addLayout(self.__horizontalLayoutApplications)
        self.__verticalMainLayout.addItem(self.__verticalSpacer_1)
        self.__verticalMainLayout.addLayout(self.__horizontalLayoutFooter)
        self.__verticalMainLayout.setAlignment(Qt.AlignCenter)

        self.setPalette(self.__styleSheets.pal_snow_white)

    def __start_pressed(self):
        self.__buttonStart.setStyleSheet(self.__styleSheets.btn_pressed)
        
    def __start_released(self):
        self.__buttonStart.setStyleSheet(self.__styleSheets.btn_released)
        
        dialog_imageProcessing = image_processing_dialog()
        dialog_imageProcessing.showFullScreen()
        dialog_imageProcessing.exec_()

    def __buttonShutdownMenu_pressed(self):
        self.__buttonShutdownMenu.setStyleSheet(self.__styleSheets.btn_pressed)

    def __buttonShutdownMenu_released(self):
        self.__buttonShutdownMenu.setStyleSheet(self.__styleSheets.btn_released)

        dialog_shutdownReboot = window_shutdown_reboot()
        dialog_shutdownReboot.showFullScreen()
        dialog_shutdownReboot.exec_()

        if dialog_shutdownReboot.get_close_flag():
            self.close()
        else:
            pass
