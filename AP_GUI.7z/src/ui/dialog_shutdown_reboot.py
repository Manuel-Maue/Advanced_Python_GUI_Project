#!/usr/bin/python3
from os import system

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QPushButton, QSpacerItem, QSizePolicy

from ui.helper.styles import stylesheets
# from util.helper.enum.enum_logTypes import logTypes
# from util.helper.logger import logger


class window_shutdown_reboot(QDialog):
    """
    Opens a dialog to reboot or shutdown system as well as close the application.
    """
    __close_flag = False

    def __init__(self):
        super().__init__()

        # logger.addLog(logType=logTypes.INFO, text='Open dialog \'shutdown/reboot\'')

        self.__setupUI()

    def __del__(self):
        # logger.addLog(logType=logTypes.INFO, text='Close dialog \'shutdown/reboot\'')
        pass

    def __setupUI(self):
        """
        Setup user interface of shutdown/reboot dialog.
        """
        self.__styleSheets = stylesheets()

        # Layout
        self.__verticalMainLayout = QVBoxLayout(self)

        # Spacer
        self.__verticalSpacer_0 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.__verticalSpacer_1 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        # Buttons
        self.__buttonCancel = QPushButton(self)
        self.__buttonCancel.setText('Cancel')
        self.__buttonCancel.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        self.__buttonCancel.setFont(self.__styleSheets.fontButtonsLarge)
        self.__buttonCancel.setStyleSheet(self.__styleSheets.btn_released)
        self.__buttonCancel.pressed.connect(self.__buttonCancel_pressed)
        self.__buttonCancel.released.connect(self.__buttonCancel_released)

        self.__buttonClose = QPushButton(self)
        self.__buttonClose.setText('Close')
        self.__buttonClose.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        self.__buttonClose.setFont(self.__styleSheets.fontButtonsLarge)
        self.__buttonClose.setStyleSheet(self.__styleSheets.btn_released)
        self.__buttonClose.pressed.connect(self.__buttonClose_pressed)
        self.__buttonClose.released.connect(self.__buttonClose_released)

        # self.__buttonShutdown = QPushButton(self)
        # self.__buttonShutdown.setText('Shutdown')
        # self.__buttonShutdown.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        # self.__buttonShutdown.setFont(self.__styleSheets.fontButtonsLarge)
        # self.__buttonShutdown.setStyleSheet(self.__styleSheets.btn_released)
        # self.__buttonShutdown.pressed.connect(self.__buttonShutdown_pressed)
        # self.__buttonShutdown.released.connect(self.__buttonShutdown_released)

        # self.__buttonReboot = QPushButton(self)
        # self.__buttonReboot.setText('Reboot')
        # self.__buttonReboot.setFixedSize(self.__styleSheets.sizeButtonsMegaLarge)
        # self.__buttonReboot.setFont(self.__styleSheets.fontButtonsLarge)
        # self.__buttonReboot.setStyleSheet(self.__styleSheets.btn_released)
        # self.__buttonReboot.pressed.connect(self.__buttonReboot_pressed)
        # self.__buttonReboot.released.connect(self.__buttonReboot_released)

        # Assembling Layout
        self.__verticalMainLayout.addItem(self.__verticalSpacer_0)
        # self.__verticalMainLayout.addWidget(self.__buttonShutdown)
        # self.__verticalMainLayout.addWidget(self.__buttonReboot)
        self.__verticalMainLayout.addWidget(self.__buttonCancel)
        self.__verticalMainLayout.addWidget(self.__buttonClose)
        self.__verticalMainLayout.addItem(self.__verticalSpacer_1)

        self.__verticalMainLayout.setAlignment(Qt.AlignCenter)
        self.setPalette(self.__styleSheets.pal_indian_red)

    def set_close_flag(self, flag):
        """
        To set close flag. If close flag is set, the dialog will be closed (needless flag). Should removed from
        source code.
        @param flag: True for closing, False for not closing.
        """
        self.__close_flag = flag

    def get_close_flag(self):
        """
        To request if dialog should closed (remove this from source code).
        """
        return self.__close_flag

    def __buttonCancel_pressed(self):
        """
        Called by pressing cancel button to change button style to pressed.
        """
        self.__buttonCancel.setStyleSheet(self.__styleSheets.btn_pressed)

    def __buttonCancel_released(self):
        """
        Called by releasing cancel button to close this dialog as well as change the button style to released.
        """
        self.__buttonCancel.setStyleSheet(self.__styleSheets.btn_released)
        self.close()

    def __buttonClose_pressed(self):
        """
        Called by pressing close button to change button style to pressed.
        """
        self.__buttonClose.setStyleSheet(self.__styleSheets.btn_pressed)

    def __buttonClose_released(self):
        """
        Called by releasing close button to set close_flag to True, close this dialog and set button style to released.
        """
        self.__buttonClose.setStyleSheet(self.__styleSheets.btn_released)
        self.__close_flag = True
        self.close()

    # def __buttonShutdown_pressed(self):
    #     """
    #     Called by pressing shutdown button to change button style to pressed.
    #     """
    #     self.__buttonShutdown.setStyleSheet(self.__styleSheets.btn_pressed)

    # def __buttonShutdown_released(self):
    #     """
    #     Called by releasing shutdown button to shutdown the system as well as change button style to released.
    #     """
    #     self.__buttonShutdown.setStyleSheet(self.__styleSheets.btn_released)
    #     cmd = 'sudo shutdown now'
    #     try:
    #         system(cmd)

    #     except:
    #         # logger.addLog(logType=logTypes.INFO, text='False platform for command.')
    #         pass

    # def __buttonReboot_pressed(self):
    #     """
    #     Called by pressing reboot button to change button style to pressed.
    #     """
    #     self.__buttonReboot.setStyleSheet(self.__styleSheets.btn_pressed)

    # def __buttonReboot_released(self):
    #     """
    #     Called by releasing reboot button to reboot system as well as change button style to released.
    #     """
    #     self.__buttonReboot.setStyleSheet(self.__styleSheets.btn_released)
    #     cmd = 'sudo reboot now'
    #     try:
    #         system(cmd)

    #     except:
    #         # logger.addLog(logType=logTypes.ERROR, text='False platform for command')
    #         print('bla')
