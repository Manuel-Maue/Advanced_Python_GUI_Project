from PyQt5.QtCore import QSize
from PyQt5.QtGui import QColor, QPalette, QFont

import pyautogui

class stylesheets():  # ()
    """
    For different stylesheets such as button styles, background colors or font styles.
    """
    def __init__(self):
        """
        Constructor
        """
        self.btn_pressed = ('border-style: outset;'
                        'border-width: 2px;'            #1px
                        'border-radius: 5px;'
                        'border-color: rgb(50, 100, 128);'  # gray, (100, 200, 255)
                        'padding: 4px;'
                        'background: rgb(249, 252, 255);')                  # white

        self.btn_released = ('border-style: outset;'
                        'border-width: 2px;'            #1px
                        'border-radius: 5px;'
                        'border-color: grey;'
                        'padding: 4px;'
                        'background: rgb(245, 245, 245);')               # lightgray

        self.__snow_white = QColor(255, 252, 255)
        self.pal_snow_white = QPalette()
        self.pal_snow_white.setColor(QPalette.Background, self.__snow_white)

        self.__indian_red = QColor(205, 92, 92)
        self.pal_indian_red = QPalette()
        self.pal_indian_red.setColor(QPalette.Background, self.__indian_red)

        self.fontTitle = QFont()
        self.fontTitle.setPointSize(20)
        self.fontTitle.setBold(True)

        self.fontButtonsLarge = QFont()
        self.fontButtonsLarge.setPointSize(int(pyautogui.size().width/80))

        self.fontButtonsLarge_bold = QFont()
        self.fontButtonsLarge_bold.setPointSize(int(pyautogui.size().width/80))
        self.fontButtonsLarge_bold.setBold(True)

        self.fontButtonsMegaLarge = QFont()
        self.fontButtonsMegaLarge.setPointSize(int(pyautogui.size().width/60))

        self.fontButtonsMegaLarge_bold = QFont()
        self.fontButtonsMegaLarge_bold.setPointSize(int(pyautogui.size().width/60))  # 120
        self.fontButtonsMegaLarge_bold.setBold(True)

        self.sizeButtonsMegaLarge = QSize(int(pyautogui.size().width / 5), int(pyautogui.size().height / 6))