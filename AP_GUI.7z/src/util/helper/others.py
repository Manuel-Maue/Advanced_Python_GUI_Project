import pathlib

def getPathImg():
    """
    Reads and returns path of image directory. Images used in the gui are in it.
    @return: path to image directory
    """
    path = str(pathlib.Path(__file__)).replace('/src/util/helper/others.py', '/').replace('\\src\\util\\helper\\others.py', '\\')
    path += '/data/img/'

    return path