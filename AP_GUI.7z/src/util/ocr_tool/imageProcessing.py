from PyQt5.QtCore import QThread, pyqtSignal, pyqtSlot

import cv2
import os
import time
import numpy as np

class imageProcessing(QThread):

    image = None
    
    grayscaleFlag = bool
    binaryFlag = bool
    cannyFlag = bool

    redValue = int
    greenValue = int
    blueValue = int

    thresholdValue = int

    def __init__(self):
        """
        Constructor
        """
        
        super().__init__()

    def non_overflowing_sum(self, array, colorValue):
        tmpArray = np.uint16(array) + colorValue
        tmpArray [np.where(tmpArray>255)] = 255
        return np.uint8(tmpArray)
    
    def non_underflowing_sum(self, array, colorValue):
        tmpArray = np.float16(array) + colorValue
        tmpArray[np.where(tmpArray<0)] = 0
        return np.uint8(tmpArray)

    def processingColors(self):
        self.redPlane = self.image[:,:,0]
        self.greenPlane = self.image[:,:,1]
        self.bluePlane = self.image[:,:,2]

        print(self.redValue)
        print(self.greenValue)
        print(self.blueValue)

        if self.redValue > 0 :
            self.redPlane = self.non_overflowing_sum(self.redPlane,self.redValue)
        if self.redValue < 0:
            self.redPlane = self.non_underflowing_sum(self.redPlane,self.redValue)
        if self.greenValue > 0 :
            self.greenPlane = self.non_overflowing_sum(self.greenPlane,self.greenValue)
        if self.greenValue < 0:
            self.greenPlane = self.non_underflowing_sum(self.greenPlane,self.greenValue)
        if self.blueValue > 0 :
            self.bluePlane = self.non_overflowing_sum(self.bluePlane,self.blueValue)
        if self.blueValue < 0:
            self.bluePlane = self.non_underflowing_sum(self.bluePlane,self.blueValue)

        print(self.redPlane.sum())
        print(self.greenPlane.sum())
        print(self.bluePlane.sum())

        self.image = np.dstack((self.redPlane,self.greenPlane,self.bluePlane))

        # cv2.imshow('stacked', self.image)
        
    def processing(self):
        self.processingColors()
        print(self.grayscaleFlag)
        print(self.binaryFlag)
        print(self.cannyFlag)
        print(self.thresholdValue)
        if self.cannyFlag:
            self.image = cv2.Canny(self.image,self.thresholdValue,255)
            return self.image

        else:
            pass

        if self.grayscaleFlag:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)

            if self.binaryFlag:
                retTMP, self.image = cv2.threshold(self.image,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)

            else:
                pass
            
        else:
            pass

        return self.image

    def run(self):       # not implemented 
        """
        TODO
        Thread of imageProcessing.
        """

        print('Ende gelände')
        time.sleep(0.1)